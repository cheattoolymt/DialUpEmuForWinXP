Windows XP SP3 x86 diagnostic build (Steps 3-5)

Source commit: 4153755bb4777e3647d527f56c2cff929bb32a41
Built on Linux with MinGW-w64 GCC 14.2.0 / i686 / MSVCRT.
XP hardware/VM runtime has NOT been tested.
This diagnostic does NOT provide Internet NAT or LAN/Wi-Fi isolation.

1. Extract the entire ZIP into one folder on Windows XP.
2. Open cmd.exe in that folder.
3. Run xp-smoke.exe (loader, clock, AT and pending-I/O tests).
4. Run vmodem-xp.exe --audio-test (400 Hz tone for about 1 second).
5. For modem tests, configure com0com and run:
   vmodem-xp.exe -c config-xp.ini -p CNCB0
   Then dial 0120-000-0000 from the opposite virtual COM port.

No separately supplied runtime DLL is linked: only KERNEL32, MSVCRT,
WINMM and WS2_32, provided by Windows, appear in the import table.
Passing the PE/import checks does NOT guarantee XP runtime compatibility.
