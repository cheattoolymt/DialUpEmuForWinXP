XP SP3 x86 idle-CPU fix and low-CPU audio diagnostic
Source: c83467902ac1374b1d935c6d58fd8dbba60ed997

Stop the old emulator and replace vmodem-xp.exe. Keep your existing config-xp.ini.
Start with your usual command and check CPU use before dialing.
Try: vmodem-xp.exe --audio-test
A 400 Hz tone should play for about one second.

Fixes a COM empty-read busy loop by honoring the requested input wait.
Also prefers 8000 Hz mono and skips unnecessary FIR resampling.
The log shows the rate/channels actually accepted by your driver.
Connection behavior and audio sequence durations are unchanged.
Host regression, existing 371 checks and x86 build/import checks passed.
This build has not been retested on the affected XP machine.
Internet NAT and physical NIC isolation are still not implemented.
