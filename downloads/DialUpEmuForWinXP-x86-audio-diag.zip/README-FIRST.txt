XP SP3 x86 dialing-audio diagnostic
Source: d5351b2a3cce77c6f745044bc1c3e73a196c9e62

Stop the old emulator and replace vmodem-xp.exe. Keep your existing config-xp.ini.
Run without the emulator server already open:
vmodem-xp.exe --dial-audio-test > dial-audio-test.txt 2>&1

This plays the default V.34+ 33600 dialing sound (about 18.32 seconds)
without opening COM, RAS or a network connection. Uses built-in defaults,
not your config. Log includes expected/elapsed time, rendering time and
missing/empty frames. Please report whether this is slow too and return
the log. Normal server startup remains the same.

This is a diagnostic addition, not a confirmed fix for the XP audio slowdown.
The previous COM idle-CPU fix and low-CPU audio path are included.
Internet NAT and physical NIC isolation are still not implemented.
